package com.example.test.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.test.model.Bus;
import com.example.test.repository.BusRepository;


@RestController
@RequestMapping("/bus")
public class BusController {

 @Autowired
 private BusRepository repo;


 @PostMapping("/book")
 public Map<String, Object> save(@RequestBody Bus b){
  repo.save(b);
  Bus bus = repo.findById(b.getBookingId())
          
          .orElseThrow();

  Map<String, Object> response = new HashMap<>();
  response.put("bookingId",bus.getBookingId());
  response.put("passengerName",bus.getPassengerName());
  response.put("finalFare",bus.getTicket_Fare());
  response.put("bookingStatus","CONFIRMED");

  return response;
  
 }
}
