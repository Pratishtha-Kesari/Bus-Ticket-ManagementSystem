package com.example.test.model;

import jakarta.persistence.Id;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Table;

@Entity
@Table(name="bus")
public class Bus {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "booking_id")
	private long BookingId;
	private String PassengerName;
	private String BusNumber;
	private String Source;
	private String destination;
	private long fare;

	
	public long getBookingId() {
			return BookingId;
		}
		public void setBookingId(long bookingId) {
			this.BookingId = bookingId;
		}
	
	public String getPassengerName() {
		return PassengerName;
	}
	public void setPassengerName(String passengerName) {
		this.PassengerName = passengerName;
	}
	public String getBus_Number() {
		return BusNumber;
	}
	public void setBus_Number(String busNumber) {
		this.BusNumber = busNumber;
	}
	public String getSource() {
		return Source;
	}
	public void setSource(String source) {
		this.Source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public long getTicket_Fare() {
		return fare;
	}
	public void setTicket_Fare(long fare) {
		this.fare = fare;
	}

}
