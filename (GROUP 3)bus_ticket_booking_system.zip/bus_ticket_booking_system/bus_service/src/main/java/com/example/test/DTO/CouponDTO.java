package com.example.test.DTO;



public class CouponDTO {

    private String couponCode;
    private int discountPercentage;
    private boolean valid;


   

    public String getCouponCode() {
        return couponCode;
    }

    public int getDiscountPercentage() {
        return discountPercentage;
    }

    public boolean isValid() {
        return valid;
    }
}
