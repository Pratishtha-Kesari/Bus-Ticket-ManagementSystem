package com.example.test.controller;


import com.example.test.*;
import com.example.test.model.Coupon;
import com.example.test.repository.CouponRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/coupons")
public class CouponController {

	 @Autowired
	 private CouponRepository repo;
    // Add new coupon
    @PostMapping
    public Map<String, Object> save(@RequestBody Coupon coupon) {
        repo.save(coupon);
        Coupon bus = repo.findById(coupon.getCouponId())
                
                .orElseThrow();

        Map<String, Object> response = new HashMap<>();
        response.put("couponId",coupon.getCouponId());
        response.put("couponCode",coupon.getCouponCode());
        response.put("discountPercentage",coupon.getDiscountPercentage());
        response.put("active",coupon.isActive());

        return response;
    }
    
    // Validate coupon
    @GetMapping("/{code}")
    public Map<String, Object> validateCoupon(@PathVariable String code) {

        Map<String, Object> response = new HashMap<>();

        Optional<Coupon> couponOpt = repo.findByCouponCode(code);

        if (couponOpt.isPresent()) {
            Coupon coupon = couponOpt.get();

            
            response.put("couponcode", coupon.getCouponCode());
            response.put("discountPercentage", coupon.getDiscountPercentage());
            response.put("valid",coupon.isActive());
    
        } else {
            response.put("valid", false);
            response.put("message", "Invalid coupon code");
        }

        return response;
    }
}
